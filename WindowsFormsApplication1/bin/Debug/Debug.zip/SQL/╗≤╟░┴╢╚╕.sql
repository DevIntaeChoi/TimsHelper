select * from tbl_Goods_Code where GoodsCode = '18015111'

select * from tbl_Goods_Master where GoodsCode = '18015111'
