select top 100 *
from tbl_Goods_Code where GoodsCode='18010871'