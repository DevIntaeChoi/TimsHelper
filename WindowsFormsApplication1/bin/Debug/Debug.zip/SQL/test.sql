select top 10000 *
from tbl_Booking_SeatAssign