select *
from tbl_Place_Master with (nolock)
where PlaceCode = '18001373'