select top 10 *
from tbl_Booking_Master with (nolock)
order by bDate desc