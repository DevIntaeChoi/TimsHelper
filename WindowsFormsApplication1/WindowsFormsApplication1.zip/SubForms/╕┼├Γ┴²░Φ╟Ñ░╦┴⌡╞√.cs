﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimsHelper.SubForms
{
    public partial class 매출집계표검증폼 : Form
    {
        string dbServer = string.Empty;

        public 매출집계표검증폼(string DBServer)
        {
            InitializeComponent();
            this.dbServer = DBServer;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = null;
                dataGridView1.Rows.Clear();
                dataGridView1.Refresh();

                SqlDataAdapter dataAdapter = new SqlDataAdapter();

                string selectCommand = @"declare @SalesDateFrom varchar(8) = '" + textBox1.Text + @"'
                , @SalesDateTo varchar(8) = '" + textBox2.Text + @"'

                -- 임시테이블 삭제
                If exists (select * from tempdb.dbo.sysobjects with (nolock) where id = object_id(N'tempdb.[dbo].#tmp') and xtype in (N'U'))
                Begin
	                Drop table #tmp
                End


                select sd.GoodsCode, sd.PlaceCode, sd.PlaySeq
                --, sum(case when GroupID = 'OTHER' then TotAmt else 0 end) OTHERAmt
                --, sum(case when GroupID = 'PLAN' then TotAmt else 0 end) PLANAmt
                , sum(TotAmt) as SDSum
                , cast(0 as float) ADSum
                into #tmp
                from tbl_SalesTotal_Daily sd with (nolock)
	                inner join tbl_Goods_Sales gs with (nolock) on sd.GoodsCode = gs.GoodsCode and sd.PlaySeq = gs.PlaySeq
                where 1=1
                --and sd.GoodsCode = '14000326' 
                and SalesGroupID <> 'NOTIN'
                and gs.PlayDate between @SalesDateFrom and @SalesDateTo
                --and sd.KindOfSale in ('SS001', 'SS002', 'SS003')
                group by sd.GoodsCode, sd.PlaceCode, sd.PlaySeq

                select *
                from (
                select sd.GoodsCode, sd.PlaceCode, sd.PlaySeq, cast(sd.SDSum as float) SDSum
                , sum(case when ad.NormalOrCancel = 'N' then ad.TicketAmt else -ad.TicketAmt end) ADSum
                from #tmp sd
	                inner join tbl_Account_Daily ad with (nolock) on sd.GoodsCode = ad.GoodsCode and sd.PlaceCode = ad.PlaceCode and sd.PlaySeq = ad.PlaySeq
                group by sd.GoodsCode, sd.PlaceCode, sd.PlaySeq, sd.SDSum
                ) A
                where SDSum <> ADSum

                ";

                selectCommand += " order by seq desc";

                string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[this.dbServer].ConnectionString;

                // Create a new data adapter based on the specified query.
                dataAdapter = new SqlDataAdapter(selectCommand, connectionString);

                // Create a command builder to generate SQL update, insert, and
                // delete commands based on selectCommand. These are used to
                // update the database.
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

                // Populate a new data table and bind it to the BindingSource.
                DataTable dt = new DataTable();
                //table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(dt);

                dataGridView1.DataSource = dt;
            } catch ( Exception ex )
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
