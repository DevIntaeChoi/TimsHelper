﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimsHelper.SubForms
{
    public partial class 매출집계표요약폼 : Form
    {
        public 매출집계표요약폼()
        {
            InitializeComponent();
        }
    }
}
